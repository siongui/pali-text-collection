tipitaka.rte
============

text ripped from BUDSIR
